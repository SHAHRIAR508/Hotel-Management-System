import java.util.Scanner;
import Entity.*;
import EntityList.*;
import GUI.*;
public class Start{
	public static void main(String args[]){
		
		StudentPage sp = new StudentPage();
	}
}