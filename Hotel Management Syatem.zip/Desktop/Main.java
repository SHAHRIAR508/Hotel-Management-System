

//import GUI.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Scanner;
//import Entity.*;
//import EntityList.*;
//import GUI.*;

//import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Login login = new Login();
    }
}
